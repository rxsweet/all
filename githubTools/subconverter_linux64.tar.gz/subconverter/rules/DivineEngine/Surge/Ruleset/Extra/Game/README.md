## 使用说明

本目录下的分流最直接的使用方法就是引用后策略使用代理。

但仍然建议先试用 [UsbEAm Hosts Editor](https://www.dogfight360.com/blog/475/) 或 [UsbEAm Consoles DNS](https://www.dogfight360.com/blog/1845/)。

如 Origin 的下载服务器 `origin-a.akamaihd.net` 使用合适的 hosts 后直连可跑满宽带，在遇到满意的 hosts 可加入到 Surge 的 `[Host]` 然后添加相应规则直连使用。