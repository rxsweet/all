---
layout: post
title: 经验技术 - Hexo部署Vercel实现双线部署
date:   2022-08-10
tags: [blog]
updated: 2023-02-13 14:50:52categories: 经验技术
img: 
---

# Hexo部署Vercel实现双线部署

在文章["hexo博客使用Github Action自动部署"](/2022/08/10/2022-08-10-经验技术-hexo博客使用GithubAction自动部署/)中实现了网站部署到`GitHub`,现在接着部署到Vercel.com

## 1.打开Vercel

	[https://vercel.com/](https://vercel.com/) 
	
## 2.使用github账号登录

	使用github账号验证登录
	
<!--more-->
	
## 3.New Project

	在`New Project`下面，`Import Git Repository -- 找到 github里的 xxx.github.io,`
	选择单个repository权限,
	完成后稍等，刷新，在`import Git Repository`下面出现了`xxx.github.io`,点击后面的`import`,
	在下一步`Deploy`,
	完成，部署成功。
	
## 4.在部署完成后修改Domains

	在部署完成后,`setting -- Domains -- Edit`,编辑自己想要的`xxx.vercel.app`域名
	
	OK,大功告成！
