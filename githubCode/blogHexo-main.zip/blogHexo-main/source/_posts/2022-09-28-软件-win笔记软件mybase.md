---
layout: post
title: 软件 - win笔记软件mybase
date:   2022-09-28
tags: [软件]
updated: 2023-02-13 15:31:09categories: 软件
img: 
---

# 前言

>自己使用的 'mybase' 和 '资料收藏大师v3.78'
>
>资料收藏大师v3.78 非常优秀，但是新系统使用时有点卡
>
>现用的mybase好用，支持md

<!--more-->
下载地址：


产品介绍：

mybase软件可以将电脑上的文档、知识、笔记、日记、图片和网页进行分类存储和管理，最终创建出一个专属于自己的个人知识库。

Mybase 是一个功能强大且可随心所欲自定义格式及层次关系的通用资料压缩管理器，
可用于管理各种各样的信息，如：各类文档、磁盘文件、资料、名片、事件、下载的精华、收集的资料等等，
即使毫无规律的资料，也一样可以管理得有条不紊。
若您善于管理资料，Mybase 将会成为您得心应手的工具，
若您不善于管理资料，Mybase 将会有助于您提高资料管理能力。

下载地址：
 -[https://www.lanzouj.com/iadgc4f](https://www.lanzouj.com/iadgc4f)

 -[https://www.lanzoui.com/ial56vi](https://www.lanzoui.com/ial56vi)

 -[http://ct.ghpym.com/d/7369060-28597496-5be18f](http://ct.ghpym.com/d/7369060-28597496-5be18f)

 -[https://www.123pan.com/s/HQeA-BH4Sh](https://www.123pan.com/s/HQeA-BH4Sh)

科学安装步骤：

安装7.3.5版本
在关闭Mybase的情况下，将破解包中的exe取出替换安装目录下的同名程序.
启动mybase，点击帮助->产品注册中使用任意字符即可注册