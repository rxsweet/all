---
layout: post
title: 经验技术 - 博客从Jekyll更换到Hexo
date:   2022-08-09
tags: [blog]
updated: 2023-02-13 15:31:09categories: 经验技术
img: 
---

# 博客从Jekyll更换到Hexo

## 前言

更换原因：1.电脑系统升级了，Win10x64
          2.Vercel对Jekyll不友好，不支持`Liquid`模板语言来处理模板
          3.Hexo主题的好多问题search可以解决

<!--more-->

# Hexo 安装

到官网自己搜索安装 [https://hexo.io/](https://hexo.io/)
	
# Hexo 主题

在静态博客框架中，Hexo 向来是最受青睐的选择，没有之一。

Jekyll 作为 GitHub 官方支持的框架，可以直接托管源码而无需手动生成静态网页，
Hugo 借助 Go 语言的性能优势，号称全世界最快的框架，
然而这两者都有一点远落后于 Hexo，那就是最为关键的主题生态
Hexo 使用 Node.js 开发，从语言层面上就吸引了大批优秀的前端工程师，精美主题可以说是层出不穷。

Hexo推荐2款主题 ：[ Butterfly ](https://butterfly.js.org) [NexT](https://theme-next.js.org/)

## Hexo主体设置修改

在 Hexo 中有两份主要的配置文件，其名称都是 `_config.yml`。 
其中，一份位于站点根目录下，主要包含 Hexo 本身的配置；
另一份位于主题目录下，这份配置由主题作者提供，主要用于配置主题相关的选项。

为了描述方便，在以下说明中，将前者称为 `站点配置文件`， 后者称为 `主题配置文件`

### 启用NexT主题

	1.下载最新NexT主题后，放到站点目录的`themes`文件夹下面
	2.打开 `_config.yml站点配置文件`，修改为`theme: next`
	3.在`# Site`下面设置站点信息,下面是自己目前设置
```
# Site
title: Sweet RX's blog
subtitle: 人生在勤 不索何获
description: This is my internet world!
keywords:
author: Sweet RX
language:
timezone:
```

### NexT主题设置

在`themes\next\`里面找到`_config.yml主题配置文件`,
	1.修改`Schemes`,自己使用的是`scheme: Gemini` 
	2.在`menu:`下面根据自己需要修改
	3.在`avatar:`下面修改博主图片
	4.在`favicon:`下面修改站点图标
	5.更多修改在`主题配置文件`自己探索

# 后语

后面根据Github Actions + Vercel 实现自动部署 + 双线网站；



