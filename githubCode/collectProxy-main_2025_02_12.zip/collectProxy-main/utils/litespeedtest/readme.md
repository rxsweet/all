# lite speedtest 

移动位置需要修改的地方：

1.set_config.py文件里：config_file_path = './utils/litespeedtest/lite_config.json'

2.output.py文件里：config_file_path = './utils/litespeedtest/lite_config.json'

3.speedtest.sh文件里2处：'#开始运行 Clash' 和 '#运行 LiteSpeedTest'
