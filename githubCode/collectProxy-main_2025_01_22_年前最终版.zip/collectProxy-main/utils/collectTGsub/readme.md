# CollectProxySource

copy https://github.com/RenaLio/proxy-minging/

## 说明

Config.yaml	--- 爬取源

main.py --- 主程序

requirements.txt --- 依赖包

## 设置

在main.py :
```
#爬取源
TGconfigListPath = './utils/collectTGsub/config.yaml'
#输出位置
path_yaml = './utils/collectTGsub/TGsources.yaml'
node_output_path = './sub/sources/crawlTGnode'
```
