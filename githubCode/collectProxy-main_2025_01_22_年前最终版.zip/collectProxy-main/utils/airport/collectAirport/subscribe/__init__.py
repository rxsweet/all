import os
import sys

PATH = os.path.abspath(os.path.dirname(__file__))
sys.path.append(PATH)
