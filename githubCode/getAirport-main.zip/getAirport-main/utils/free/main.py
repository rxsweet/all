import freev2
import qqfreev2
import freess

if __name__=='__main__':
    freev2.get_conf()   # 获取 V2board 类网站的，需用Gmail邮箱注册的订阅信息
    qqfreev2.get_conf() # 获取 V2board 类网站的，需用QQ邮箱注册的订阅信息
    freess.get_conf()
