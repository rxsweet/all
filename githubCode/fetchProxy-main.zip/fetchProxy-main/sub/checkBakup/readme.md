LiteSpeedtest 测速后的out.json,speedtest.log文件备份位置
