import waiqi

waiqi.getconf()
