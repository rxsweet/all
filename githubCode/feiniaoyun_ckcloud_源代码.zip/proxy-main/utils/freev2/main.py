import freev2

freev2.getconf()
