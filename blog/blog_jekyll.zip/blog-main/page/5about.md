---
layout: page
title: About
permalink: /about/
icon: user
type: page
---

* content
{:toc}

## 关于我

<!-- <iframe src="https://githubbadge.appspot.com/gaohaoyang?s=1" style="border: 0;height: 142px;width: 200px;overflow: hidden;" frameBorder="0"></iframe> -->

## 联系我

<!-- 
* GitHub：[Gaohaoyang](https://github.com/Gaohaoyang)
* email：gaohaoyang126@126.com
* [Weibo](http://weibo.com/3115521wh)
* [知乎](https://www.zhihu.com/people/gaohaoyang)
* [豆瓣](https://www.douban.com/people/42525035/)
-->

## 友情链接

[薛彬XueBin](http://axuebin.com/blog/) 

[TBOOX](http://www.tboox.org/cn/)

## Comments

{% include comments.html %}
