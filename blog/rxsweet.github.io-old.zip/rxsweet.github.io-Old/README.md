# My blog 

My blog is a free blog template for Jekyll

Fork https://github.com/artemsheludko/fresh/ 

thanks!
