---
layout: post
title: 软件 - apk - JustLive
date:   2022-05-18 
tags: [软件,apk,开源]
img: 
---
# JustLive - 一个整合国内多个直播平台内容的App


Github开源:[https://github.com/guyijie1211/JustLive-Android](https://github.com/guyijie1211/JustLive-Android)

果核分享下载地址：[https://www.123pan.com/s/HQeA-jc1Sh](https://www.123pan.com/s/HQeA-jc1Sh)

# 介绍

目前是没有任何广告和付费项目，界面简洁(简陋？)，细节再优化一下就好了。

支持的平台：虎牙、斗鱼、BILIBILI直播、网易cc（cc暂无清晰度切换）、企鹅电竞。

基本功能都有了，如：多平台直播信息获取、关注直播间、弹幕获取、直播间搜索，因为是新应用，功能还在一步步更新，等一波定时关闭就完美了！

注意：
   APP很不错，但是可能是因为虎牙官方限制的原因，有个别频道只能看几秒就会中断，如：周星星等，JustLive存在这个问题，等待以后有更好的方法修复吧！

