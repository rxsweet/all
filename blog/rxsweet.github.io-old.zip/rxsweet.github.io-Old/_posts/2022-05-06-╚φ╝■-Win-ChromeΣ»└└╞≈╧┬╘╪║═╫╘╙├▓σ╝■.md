---
layout: post
title: 软件-win-Chrome浏览器下载和自用插件
date:   2022-05-06 
tags: [chrome,软件,win]
img: 
---
更新于2022-05-09

# 一、chrome下载

### 1.☆推荐下载：MyChrome_v3.8.38

https://github.com/Jason4774/MyChrome  - 作者github

- [原版32位https://raw.githubusercontents.com/Jason4774/MyChrome/master/MyChrome_v3.8.38.7z](https://raw.githubusercontents.com/Jason4774/MyChrome/master/MyChrome_v3.8.38.7z)
- [原版64位https://cdn.jsdelivr.net/gh/Jason4774/MyChrome@master/MyChrome_v3.8.38_x64.7z](https://cdn.jsdelivr.net/gh/Jason4774/MyChrome@master/MyChrome_v3.8.38_x64.7z)

其他下载地址：

- [https://foxirj.com/mychrome](https://foxirj.com/mychrome)
- [文件中转下载https://www.progo.cc/#/](https://www.progo.cc/#/)
- 32位地址：https://raw.githubusercontent.com/Jason4774/MyChrome/master/MyChrome_v3.8.38.7z
- 64位地址：https://raw.githubusercontent.com/Jason4774/MyChrome/master/MyChrome_v3.8.38_x64.7z

---

### 2.网站下载最新版

[https://www.iplaysoft.com/tools/chrome/](https://www.iplaysoft.com/tools/chrome/) -最新版下载

[https://www.chromedownloads.net](https://www.chromedownloads.net) -chrome浏览器,chrome插件,谈笑有鸿儒

---

# 二、chrome插件

### 个人使用插件：

1. [BookmarkHub - 【书签同步】 - Crx搜搜](https://www.crxsoso.com/webstore/detail/fohimdklhhcpcnpmmichieidclgfdmol)
2. [Proxy SwitchySharp](https://www.crxsoso.com/webstore/detail/dpplabbmogkhghncfbfdeeokoefdjegm)
3. [Violentmonkey暴力猴 【脚本管理】- Crx搜搜](https://www.crxsoso.com/webstore/detail/jinjaccalgkegednnccohejagnlnfdag)
4. [Tampermonkey油猴 【脚本管理】- 极简插件](https://chrome.zzzmh.cn/info?token=dhdgffkkebhmkfjojejmpbldmpobfkfo)
5. [uBlock Origin【广告屏蔽】](https://www.crxsoso.com/webstore/detail/cjpalhdlnbpafiamejdnhcphjbkeiagm)
6. [Chrono【下载管理器】](https://www.crx4.com/30262.html)
7. [Hitomi-Downloader【视频嗅探下载】](https://github.com/KurtBestor/Hitomi-Downloader)
8. [Infinity Pro 【标签管理】](https://www.crxsoso.com/webstore/detail/nnnkddnnlpamobajfibfdgfnbcnkgngh)    - c.sml    W*53推荐
9. [iTab【标签管理】  - itab.link](https://itab.link/?from=itab) - c.sml Itab53推荐
10. [ruffle - Rus语言编写的 Flash Player模拟器](https://ruffle.rs/#what-is-ruffle)
11. [Bitwarden - 免费密码管理器 - Crx搜搜](https://www.crxsoso.com/webstore/detail/nngceckbapebfimnlniiiahkandclblb)
12. [Search by Image 以图搜图 - Crx搜搜](https://www.crxsoso.com/webstore/detail/cnojnbdhbhnkbcieeekonklommdnndci)
13. [Imagus 鼠标指针悬停预览 - Crx搜搜](https://www.crxsoso.com/webstore/detail/immpkjjlgappgfkkfieppnmlhakdmaab)](https://chrome.zzzmh.cn/info?token=dhdgffkkebhmkfjojejmpbldmpobfkfo)
14. [MyBookmark](https://raw.githubusercontent.com/cszszs/all/main/bookmarks/bookmarks)

### 插件下载网站

[https://www.crxsoso.com/](https://www.crxsoso.com/)        - Crx搜搜_现用

[https://chrome.zzzmh.cn/#/index](https://chrome.zzzmh.cn/#/index)    - 极简插件

[https://crxdl.com/](https://crxdl.com/)                - CrxDL.COM

[https://www.crx4.com/](https://www.crx4.com/)            - crx4.com

[https://www.crx4chrome.com/](https://www.crx4chrome.com/)        - 英文站

[https://www.chromedownloads.net/extensions/](https://www.chromedownloads.net/extensions/)    - 

[https://www.cnplugins.com/top/](https://www.cnplugins.com/top/)        - 要验证码

[https://huajiakeji.com/    ](https://huajiakeji.com/    )            - 要验证码

[https://www.gugeapps.net/](https://www.gugeapps.net/)            - 要验证码

---

ce88dc8671ffebefd8c599ade0533e37bookmark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

Violentmonkey
https://app.koofr.net/dav/Koofr/all/
sweetrx@pm.me
u7ao qpaa 3m75 jdvg
