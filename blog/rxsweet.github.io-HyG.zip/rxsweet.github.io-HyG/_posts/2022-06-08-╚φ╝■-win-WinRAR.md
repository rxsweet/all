---
layout: post
title: 软件 - win - WinRAR and 7-Zip
date:   2022-06-08 
tags: [软件,win]
categories: win
img: 
---

* content
{:toc}


# WinRAR

WinRAR 简体中文汉化版

网盘下载

[https://lanzoui.com/b04ako9dg](https://lanzoui.com/b04ako9dg) 提取码：3zq8

[https://423down.lanzouo.com/b105455](https://423down.lanzouo.com/b105455)

[https://ghpym.lanzoui.com/b010ja45a](https://ghpym.lanzoui.com/b010ja45a)   密码:fd15

# 7-Zip

纯净免费高效的7-Zip

[https://sparanoid.com/lab/7z/](https://sparanoid.com/lab/7z/)
