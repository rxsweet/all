---
layout: post
title: GFW-3-Web Proxy 和 记录代理池的大佬们
date:   2022-03-29 
tags: [GFW]
categories: GFW
img: 
---

* content
{:toc}


[F 搜 free proxies](https://fsoufsou.com/search?q=free proxies)

搜索下面代码
`api/v1/client/subscribe?token=`

---
## **GOOD WEB Proxy**

- http://theinternetpics.com/freeweb/        - 速度不错
- https://go.zerousd.com/a-proxy-website    - 教程和WEB代理记录

* * *

<!--more-->

## **web分享节点**

- http://isx.yt/    -- No proxy Web

挂代理

- https://lncn.org/        - good
- https://www.youneed.win/    - good
- https://free-ss.site
- http://ss.pythonic.life/full
- https://www.ssrtool.com/tool/free_ssr

* * *

## **Proxy pool note**

- https://i.sqeven.me/                    ---这哥们记录订阅池

- https://github.com/shoujiyanxishe/atu/            ---记录订阅池

- https://github.com/du5/free                ---sub.list

- https://github.com/icefishsss/freevpn/            ---记录节点池

- https://github.com/Leon406/SubCrawler            ---sub.list

- https://github.com/anaer/Sub                ---有订阅池，有订阅   

- https://github.com/Leon406/SubCrawler/tree/main/sub/pool   ---节点池

- https://github.com/GreenFishStudio/GreenFish/blob/master/File/source.yaml		- 节点源

- https://github.com/alanbobs999/TopFreeProxies/blob/master/sub/sub_list.json    - 节点池

- https://github.com/yu-steven/openit		- 节点库

- https://github.com/changfengoss/pub		- 节点库

_ _ _

- https://ednovas.xyz/
- https://www.freebaipiao.tk/
- https://github.com/freefq/free                ---需要挂代理
- https://www.winxray.com/免费节点/            -Winxray提供的VS,SS,SSR
- https://node.umelabs.dev
- https://gitea.com/proxypools/sub/src/branch/main    ---proxypools的更新慢了

* * *

## **优秀的节点更新者**

`https://github.com/adiwzx/freenode        - 更新挺快`
`https://github.com/pojiezhiyuanjun/freev2    - 更新挺快`
`https://github.com/colatiger/v2ray-nodes    - 更新挺快`
`https://github.com/huaxinCLUB/NodeSpider/    - 更新挺快 -文件名字变动`
`https://github.com/skywolf627/VmessActions/tree/main/subscribe    -更新挺快`
`https://github.com/ssrsub/ssr/tree/master    - SSRSUB`
`https://github.com/git-yusteven/openit        - 更新挺快`
`https://github.com/ThekingMX1998/free-v2ray-code/        - 更新挺快`
`https://github.com/changfengoss/pub        - 更新挺快 -文件名字变动`
`https://github.com/ronghuaxueleng/get_v2/tree/main/pub    - 更新挺快 - 高手抓取其他网站`
`https://github.com/bhqz/bhqz            - 更新挺快 -文件名字变动`
`https://github.com/shoujiyanxishe`

_ _ _

`https://github.com/ccnndwa`
`https://github.com/lion12776`
`https://github.com/a910303`
`https://github.com/AzadNetCH/Clash`
`https://github.com/Harrison-kang/Nodes`
`https://github.com/HaiLianna/Node-subscription`
`https://github.com/zyzmzyz/free-nodes`
`https://github.com/lanfxx/clashtest`
`https://github.com/freebaipiao/freebaipiao`
`https://github.com/chfchf0306/4.18clash/blob/main/Class`
`https://github.com/JieErJingFu/FreeNodesTrojanVmessSSRSS`
`https://github.com/UmeLabs/node.umelabs.dev`
`https://github.com/UmeLabs/node.umelabs.dev/tree/master/Subscribe`

_ _ _

`https://gitee.com/Mirror/clash/`
`https://gitee.com/shoujiyanxishe/atu`
`https://gitee.com/bujilangren/warehouse/`
`https://gitee.com/xihuancaoni/dotpclink/`
`https://hub.fastgit.org/freefq`

_ _ _

美帝亡我之心不死系列 —— 由某敌对势力提供的ss，有需要自取
`https://github.com/Alvin9999/new-pac/wiki/ss%E5%85%8D%E8%B4%B9%E8%B4%A6%E5%8F%B7`

* * *

## **地址连接转换**

- https://bianyuan.xyz/
- https://sub.tsutsu.cc/    
- https://zh.xxcr.cc/
- https://sub.bihai.ml/
- https://id9.cc/
- https://sublink.dev/
- https://www.con8.tk/
- https://acl4ssr.netlify.app/      - 多个API

* * *
