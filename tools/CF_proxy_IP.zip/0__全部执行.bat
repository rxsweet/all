@echo off
chcp 65001 > nul

call 1__更新IP.bat
call 2__45102-1-443去重后压缩成zip.bat
call 3__启动iptest.bat

::pause