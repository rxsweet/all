@echo off
chcp 65001 > nul
set "url1=https://ghraw.eu.org/rxsweet/cfip/main/proxyip.txt"
set "url2=https://ghraw.eu.org/rxsweet/cfip/main/ip/port443.txt"
set "url3=https://ghraw.eu.org/rxsweet/cfip/main/ip/us443.txt"
set "url4=https://ips.1985.de5.net"


:main
set menu=1
echo 1.获取无us反代IP
echo 2.只获取"ips.1985.de5.net"反代IP
echo 3.获取全部IP(包含us)
set /p menu="请选择模式(默认%menu%):"
if %menu% == 1 (
goto menu1
) else (
if %menu% == 2 (
goto menu2
) else (
if %menu% == 3 (
goto menu3
) else (
exit
)
)
)

:menu1
curl -k -s -L %url1% > 45102-1-443.txt
curl -k -s -L %url2% >> 45102-1-443.txt
echo. >> "45102-1-443.txt"
curl -k -s -L %url4% >> 45102-1-443.txt
goto end

:menu2
curl -k -s -L %url4% > 45102-1-443.txt
goto end

:menu3
curl -k -s -L %url1% > 45102-1-443.txt
curl -k -s -L %url2% >> 45102-1-443.txt
curl -k -s -L %url3% >> 45102-1-443.txt
echo. >> "45102-1-443.txt"
curl -k -s -L %url4% >> 45102-1-443.txt
goto end

:end
echo 合并完成，结果保存到 45102-1-443.txt

::pause
::上面这行是备注掉了，如果有问题需要暂停到cmd行，去掉上面的::备注命令
::echo. >> "45102-1-443.txt"	这一行强制加一个换行