@echo off
chcp 65001 > nul
set "url1=https://ghraw.eu.org/rxsweet/cfip/main/proxyip.txt"   & rem 替换为你的网址1
set "url2=https://ghraw.eu.org/rxsweet/cfip/main/ip/port443.txt"   & rem 替换为你的网址2
set "url3=https://ghraw.eu.org/rxsweet/cfip/main/ip/us443.txt"   & rem 替换为你的网址3

:main
set menu=2
echo 1.添加us443端口IP
echo 2.无us443端口IP
set /p menu="请选择模式(默认%menu%):"
if %menu% == 1 (
goto menu1
) else (
if %menu% == 2 (
goto menu2
) else (
exit
)
)

:menu1
curl -k -s -L %url1% > 45102-1-443.txt
curl -k -s -L %url2% >> 45102-1-443.txt
curl -k -s -L %url3% >> 45102-1-443.txt
goto end

:menu2
curl -k -s -L %url1% > 45102-1-443.txt
curl -k -s -L %url2% >> 45102-1-443.txt
goto end


:end
echo 合并完成，结果保存到 45102-1-443.txt

::pause
::上面这行是备注掉了，如果有问题需要暂停到cmd行，去掉上面的::备注命令
